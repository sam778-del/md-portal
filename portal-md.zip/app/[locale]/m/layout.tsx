import SignInRedirect from "@/app/components/SignInRedirect";

export default function Home() {
    return <SignInRedirect />;
}
